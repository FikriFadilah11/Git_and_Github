package javaclass;

import form_kasir.login;


public class main {

public static void main(String args[]) {
    login log = new login();
    log.setVisible(true);
    
}
}